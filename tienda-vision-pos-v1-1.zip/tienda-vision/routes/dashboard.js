import { Router } from 'express';
import express from 'express';
import { z } from 'zod';
import { AppError } from '../lib/errors.js';
import { requireApiKey } from '../lib/auth.js';

const money = z.coerce.number().finite().min(0).max(99_999_999);
const productSchema = z.object({
  producto: z.string().trim().min(1).max(200),
  marca: z.string().trim().max(100).default(''),
  codigo_barras: z.preprocess(value => value === '' ? null : value,
    z.string().trim().min(3).max(64).nullable().optional()),
  precio_costo: money,
  precio_venta: money,
  stock: z.coerce.number().int().min(0).max(1_000_000),
  stock_minimo: z.coerce.number().int().min(0).max(1_000_000).default(3)
}).strict();

export function createDashboardRouter({ config, db }) {
  const router = Router();
  router.use(requireApiKey(config));
  router.use(express.json({ limit: '32kb' }));

  router.get('/dashboard', async (req, res, next) => {
    try {
      const signal = AbortSignal.timeout(8_000);
      res.json(await db.dashboard(signal));
    } catch (error) { next(error); }
  });

  router.post('/inventory', async (req, res, next) => {
    try {
      const parsed = productSchema.safeParse(req.body);
      if (!parsed.success) throw new AppError(400, 'INVALID_PRODUCT');
      const signal = AbortSignal.timeout(8_000);
      res.status(201).json(await db.addProduct(parsed.data, signal));
    } catch (error) { next(error); }
  });

  router.patch('/alerts/:id/resolve', async (req, res, next) => {
    try {
      const id = z.string().uuid().safeParse(req.params.id);
      if (!id.success) throw new AppError(400, 'INVALID_ALERT_ID');
      const signal = AbortSignal.timeout(8_000);
      res.json(await db.resolveAlert(id.data, signal));
    } catch (error) { next(error); }
  });

  return router;
}
