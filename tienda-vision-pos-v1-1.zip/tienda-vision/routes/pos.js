import { Router } from 'express';
import express from 'express';
import { createHash } from 'node:crypto';
import { z } from 'zod';
import { AppError } from '../lib/errors.js';
import { requireApiKey } from '../lib/auth.js';

const saleSchema = z.object({
  items: z.array(z.object({
    id: z.string().uuid(),
    cantidad: z.coerce.number().int().min(1).max(100000)
  }).strict()).min(1).max(100),
  metodo_pago: z.enum(['EFECTIVO','TARJETA','TRANSFERENCIA','OTRO']).default('EFECTIVO')
}).strict();

export function createPosRouter({ config, db }) {
  const router = Router();
  router.use('/pos', requireApiKey(config));
  router.use('/pos', express.json({ limit: '64kb' }));

  router.get('/pos/catalog', async (req, res, next) => {
    try {
      const barcode = typeof req.query.barcode === 'string' ? req.query.barcode.trim() : '';
      if (barcode && (barcode.length < 3 || barcode.length > 64)) {
        throw new AppError(400, 'INVALID_BARCODE');
      }
      res.json(await db.posCatalog(barcode || null, AbortSignal.timeout(8_000)));
    } catch (error) { next(error); }
  });

  router.post('/pos/sales', async (req, res, next) => {
    try {
      const key = req.get('idempotency-key');
      if (!key || !/^[a-zA-Z0-9_.:-]{8,128}$/.test(key)) {
        throw new AppError(400, 'IDEMPOTENCY_KEY_REQUIRED');
      }
      const parsed = saleSchema.safeParse(req.body);
      if (!parsed.success) throw new AppError(400, 'INVALID_POS_SALE');
      const sale = parsed.data;
      sale.items.sort((a, b) => a.id.localeCompare(b.id));
      if (new Set(sale.items.map(item => item.id)).size !== sale.items.length) {
        throw new AppError(400, 'DUPLICATE_PRODUCT');
      }
      const hash = createHash('sha256').update(JSON.stringify(sale)).digest('hex');
      const result = await db.registerPosSale(key, hash, sale, AbortSignal.timeout(8_000));
      res.status(201).json(result);
    } catch (error) { next(error); }
  });

  return router;
}
