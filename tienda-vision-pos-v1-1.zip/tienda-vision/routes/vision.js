import { Router } from 'express';
import express from 'express';
import multer from 'multer';
import { createHash } from 'node:crypto';
import { AppError } from '../lib/errors.js';
import { requireApiKey } from '../lib/auth.js';
import { inputSchema, validateScene } from '../lib/validation.js';
import { MAX_IMAGE_BYTES, decodeBase64, resizeImage } from '../lib/image.js';
export function createVisionRouter({ config, db, analyze }) {
  const router = Router();
  let active = 0;
  const upload = multer({ storage: multer.memoryStorage(), limits: {
    fileSize: MAX_IMAGE_BYTES, files: 1, fields: 8, fieldSize: 8192, parts: 9
  } }).single('image');
  const json = express.json({ limit: '9mb', inflate: false });
  router.post('/cam-event', requireApiKey(config), (req, res, next) => {
    if (active >= 2) { res.set('Retry-After', '3'); return next(new AppError(503, 'BUSY')); }
    active++;
    req.deadline = new AbortController();
    let released = false;
    req.release = () => { if (!released) { released = true; active--; } };
    const timer = setTimeout(() => {
      req.deadline.abort();
      if (!res.headersSent) res.status(504).json({ error: 'DEADLINE_EXCEEDED_RETRY_SAME_KEY' });
    }, 10_000);
    timer.unref();
    res.once('close', () => { clearTimeout(timer); if (!res.writableFinished) req.deadline.abort(); });
    res.once('finish', () => clearTimeout(timer));
    // Bound upload + preprocessing + provider + DB by the same deadline.
    next();
  }, (req, res, next) => {
    const done = err => { if (err) req.release(); next(err); };
    if (req.is('multipart/form-data')) return upload(req, res, done);
    if (req.is('application/json')) return json(req, res, done);
    req.release(); next(new AppError(415, 'USE_JSON_OR_MULTIPART'));
  }, async (req, res, next) => {
    try {
      const signal = req.deadline.signal;
      signal.throwIfAborted();
      const key = req.get('idempotency-key');
      if (!key || !/^[a-zA-Z0-9_.:-]{8,128}$/.test(key)) throw new AppError(400, 'IDEMPOTENCY_KEY_REQUIRED');
      const parsed = inputSchema.safeParse(req.body || {});
      if (!parsed.success) throw new AppError(400, 'INVALID_METADATA');
      const meta = parsed.data;
      if (meta.product_ids) meta.product_ids = [...new Set(meta.product_ids)].sort();
      const bytes = req.file?.buffer || decodeBase64(req.body?.image);
      // Hash original bytes and normalized metadata; retries must preserve both.
      const hash = createHash('sha256').update(bytes).update(JSON.stringify(meta)).digest('hex');
      const previous = await db.lookup(key, signal);
      if (previous) {
        if (previous.hash !== hash) throw new AppError(409, 'IDEMPOTENCY_CONFLICT');
        return res.status(200).json({ ...previous.respuesta, duplicate: true });
      }
      const image = await resizeImage(bytes);
      signal.throwIfAborted();
      const catalog = await db.catalog(meta.product_ids, signal);
      const raw = await analyze(image, meta, catalog, signal);
      const scene = validateScene(raw, catalog, meta);
      signal.throwIfAborted();
      const result = await db.apply(key, hash, scene, meta, catalog, signal);
      if (!res.headersSent) res.status(result.estado === 'REVISION' ? 202 : 200).json(result);
    } catch (e) { next(e); }
    finally { req.release(); }
  });
  return router;
}
