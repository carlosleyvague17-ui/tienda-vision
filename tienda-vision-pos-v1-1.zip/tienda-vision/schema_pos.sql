-- Evolución no destructiva: venta rápida sin cámara y bitácora de inventario.
-- Aplicar después de schema.sql.
begin;

alter table public.inventario
  add column codigo_barras text,
  add column stock_minimo integer not null default 3 check (stock_minimo >= 0 and stock_minimo <= 1000000),
  add column activo boolean not null default true;

alter table public.inventario
  add constraint inventario_codigo_barras_formato
  check (codigo_barras is null or length(btrim(codigo_barras)) between 3 and 64);

create unique index inventario_codigo_barras_unico
  on public.inventario (codigo_barras)
  where codigo_barras is not null;
create index inventario_activo_producto on public.inventario (activo, producto);

alter table public.ventas
  add column metodo_pago text not null default 'EFECTIVO'
    check (metodo_pago in ('EFECTIVO','TARJETA','TRANSFERENCIA','OTRO')),
  add column origen text not null default 'VISION'
    check (origen in ('VISION','POS'));

create table public.venta_partidas (
  id uuid primary key default gen_random_uuid(),
  venta_id uuid not null references public.ventas(id) on delete restrict,
  producto_id uuid not null references public.inventario(id) on delete restrict,
  producto text not null,
  marca text not null default '',
  cantidad integer not null check (cantidad > 0),
  precio_unitario numeric(12,2) not null check (precio_unitario >= 0),
  subtotal numeric(14,2) not null check (subtotal >= 0)
);
create index venta_partidas_venta on public.venta_partidas(venta_id);
create index venta_partidas_producto on public.venta_partidas(producto_id);

create table public.movimientos_inventario (
  id uuid primary key default gen_random_uuid(),
  fecha timestamptz not null default clock_timestamp(),
  producto_id uuid not null references public.inventario(id) on delete restrict,
  tipo text not null check (tipo in ('VENTA','RECEPCION','AJUSTE','CANCELACION')),
  cantidad integer not null check (cantidad <> 0),
  stock_anterior integer not null check (stock_anterior >= 0),
  stock_nuevo integer not null check (stock_nuevo >= 0),
  referencia_tipo text not null,
  referencia_id text not null,
  detalle jsonb not null default '{}'::jsonb
);
create index movimientos_producto_fecha on public.movimientos_inventario(producto_id, fecha desc);
create index movimientos_referencia on public.movimientos_inventario(referencia_tipo, referencia_id);
create index alertas_evento on public.alertas(evento_id) where evento_id is not null;

alter table public.venta_partidas enable row level security;
alter table public.movimientos_inventario enable row level security;
revoke all on public.venta_partidas, public.movimientos_inventario from public, anon, authenticated;
grant select, insert, update, delete on public.venta_partidas, public.movimientos_inventario to service_role;

create function public.registrar_venta_pos(
  p_id text,
  p_hash text,
  p_items jsonb,
  p_metodo_pago text
) returns jsonb
language plpgsql security invoker set search_path = ''
set lock_timeout = '2s' set statement_timeout = '5s'
as $$
declare
  previo public.eventos%rowtype;
  item jsonb;
  linea jsonb;
  producto public.inventario%rowtype;
  venta_id uuid := gen_random_uuid();
  cantidad integer;
  nuevo_stock integer;
  total numeric(14,2) := 0;
  lineas jsonb := '[]'::jsonb;
  resultado jsonb;
begin
  if p_id is null or p_id !~ '^[a-zA-Z0-9_.:-]{8,128}$' or
     p_hash is null or p_hash !~ '^[a-f0-9]{64}$' or
     jsonb_typeof(p_items) is distinct from 'array' or
     jsonb_array_length(p_items) = 0 or jsonb_array_length(p_items) > 100 or
     p_metodo_pago not in ('EFECTIVO','TARJETA','TRANSFERENCIA','OTRO') then
    raise exception 'INVALID_POS_SALE';
  end if;

  perform pg_advisory_xact_lock(817344012);
  select * into previo from public.eventos where id = p_id;
  if found then
    if previo.hash <> p_hash then raise exception 'IDEMPOTENCY_CONFLICT'; end if;
    return previo.respuesta || jsonb_build_object('duplicate', true);
  end if;

  if exists(
    select 1 from jsonb_array_elements(p_items) x
    group by x->>'id' having count(*) > 1
  ) then raise exception 'INVALID_POS_SALE'; end if;

  lock table public.inventario in share row exclusive mode;
  for item in select value from jsonb_array_elements(p_items) order by value->>'id' loop
    if coalesce(item->>'id','') !~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-[89aAbB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$' or
       coalesce(item->>'cantidad','') !~ '^\d{1,6}$' then
      raise exception 'INVALID_POS_SALE';
    end if;
    cantidad := (item->>'cantidad')::integer;
    if cantidad < 1 or cantidad > 100000 then raise exception 'INVALID_POS_SALE'; end if;

    select * into producto from public.inventario
      where id = (item->>'id')::uuid and activo = true for update;
    if not found then raise exception 'UNKNOWN_PRODUCT'; end if;
    if producto.stock < cantidad then raise exception 'INSUFFICIENT_STOCK'; end if;

    nuevo_stock := producto.stock - cantidad;
    total := total + (cantidad * producto.precio_venta);
    lineas := lineas || jsonb_build_array(jsonb_build_object(
      'id', producto.id,
      'producto', producto.producto,
      'marca', producto.marca,
      'cantidad', cantidad,
      'precio_venta', producto.precio_venta,
      'subtotal', cantidad * producto.precio_venta,
      'stock_anterior', producto.stock,
      'stock_nuevo', nuevo_stock
    ));

    update public.inventario set stock = nuevo_stock where id = producto.id;
    if nuevo_stock <= producto.stock_minimo then
      insert into public.alertas(mensaje,producto_id,evento_id)
        values('Existencia baja: ' || producto.producto || ' (' || nuevo_stock || ')',producto.id,p_id)
        on conflict (producto_id) where resuelto = false and producto_id is not null do nothing;
    else
      update public.alertas set resuelto = true
        where producto_id = producto.id and resuelto = false;
    end if;
  end loop;

  insert into public.ventas(id,productos_json,total_venta,evento_id,metodo_pago,origen)
    values(venta_id,lineas,total,p_id,p_metodo_pago,'POS');

  for linea in select value from jsonb_array_elements(lineas) loop
    insert into public.venta_partidas(
      venta_id,producto_id,producto,marca,cantidad,precio_unitario,subtotal
    ) values (
      venta_id,(linea->>'id')::uuid,linea->>'producto',linea->>'marca',
      (linea->>'cantidad')::integer,(linea->>'precio_venta')::numeric,
      (linea->>'subtotal')::numeric
    );
    insert into public.movimientos_inventario(
      producto_id,tipo,cantidad,stock_anterior,stock_nuevo,
      referencia_tipo,referencia_id,detalle
    ) values (
      (linea->>'id')::uuid,'VENTA',-((linea->>'cantidad')::integer),
      (linea->>'stock_anterior')::integer,(linea->>'stock_nuevo')::integer,
      'VENTA',venta_id::text,jsonb_build_object('precio_venta',linea->>'precio_venta')
    );
  end loop;

  resultado := jsonb_build_object(
    'evento_id',p_id,'venta_id',venta_id,'estado','APLICADO','tipo','VENTA_POS',
    'productos',lineas,'total',total,'metodo_pago',p_metodo_pago,'duplicate',false
  );
  insert into public.eventos(id,hash,escena,metadata,respuesta)
    values(p_id,p_hash,jsonb_build_object('tipo','VENTA_POS','productos',p_items),
      jsonb_build_object('metodo_pago',p_metodo_pago),resultado);
  return resultado;
end;
$$;

revoke all on function public.registrar_venta_pos(text,text,jsonb,text) from public, anon, authenticated;
grant execute on function public.registrar_venta_pos(text,text,jsonb,text) to service_role;

commit;
