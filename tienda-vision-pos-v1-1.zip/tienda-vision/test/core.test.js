import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { PGlite } from '@electric-sql/pglite';
import request from 'supertest';
import sharp from 'sharp';
import { createApp } from '../server.js';
import { validateScene } from '../lib/validation.js';
import { resizeImage, decodeBase64 } from '../lib/image.js';
const id = '10000000-0000-4000-8000-000000000001';
const scene = (tipo='TRANSACCION', cantidad=2) => ({ tipo, requiere_revision:false, motivo:'',
  proveedor:null,numero_documento:null,total_factura:null,productos:[{id,cantidad,precio_costo:null}] });

test('SQL: atomicidad, duplicados, recepción, conteos y permisos', async () => {
  const pg = new PGlite();
  try {
    await pg.exec('create role anon; create role authenticated; create role service_role bypassrls;');
    await pg.exec(await readFile(new URL('../schema.sql', import.meta.url),'utf8'));
    await pg.exec(await readFile(new URL('../schema_pos.sql', import.meta.url),'utf8'));
    await pg.query('insert into inventario(id,producto,marca,precio_costo,precio_venta,stock) values($1,$2,$3,5,10,4)',[id,'Agua 1 L','Marca A']);
    const apply = async (key,s,meta={transaction_confirmed:true},hash='a'.repeat(64),versions={}) =>
      (await pg.query('select aplicar_evento($1,$2,$3::jsonb,$4::jsonb,$5::jsonb) as r',
        [key,hash,JSON.stringify(s),JSON.stringify(meta),JSON.stringify(versions)])).rows[0].r;
    const stock = async () => (await pg.query('select stock from inventario where id=$1',[id])).rows[0].stock;
    assert.equal((await apply('sale-0001',scene())).estado,'APLICADO');
    assert.equal(await stock(),2);
    assert.equal((await pg.query('select count(*)::int as n from alertas where not resuelto')).rows[0].n,1);
    assert.equal((await apply('sale-0001',scene())).duplicate,true);
    assert.equal(await stock(),2);
    await assert.rejects(apply('sale-0001',scene(),{},'b'.repeat(64)),/IDEMPOTENCY_CONFLICT/);
    await assert.rejects(apply('sale-0002',scene('TRANSACCION',3)),/INSUFFICIENT_STOCK/);
    assert.equal(await stock(),2);
    assert.equal((await pg.query('select count(*)::int as n from ventas')).rows[0].n,1);
    const invoice = {...scene('DOC_RECEPCION',5),proveedor:'Proveedor A',numero_documento:'F-1',total_factura:'25.00',
      productos:[{id,cantidad:5,precio_costo:'5.00'}]};
    await assert.rejects(apply('invoice-bad',{...invoice,total_factura:'26.00'},{receipt_confirmed:true}),/INVOICE_TOTAL_MISMATCH/);
    assert.equal(await stock(),2);
    await apply('invoice-0001',invoice,{receipt_confirmed:true});
    assert.equal(await stock(),7);
    await assert.rejects(apply('invoice-0002',invoice,{receipt_confirmed:true}),/DUPLICATE_DOCUMENT/);
    assert.equal((await pg.query('select count(*)::int as n from alertas where not resuelto')).rows[0].n,0);
    const version = (await pg.query('select actualizado_en::text as v from inventario')).rows[0].v;
    // Capture time is later than the current row version.
    const captured = new Date(Date.now()+1000).toISOString();
    await apply('count-0001',scene('INVENTARIO',6),{inventory_complete:true,captured_at:captured},'a'.repeat(64),{[id]:version});
    assert.equal(await stock(),6);
    await assert.rejects(apply('count-0002',scene('INVENTARIO',5),{inventory_complete:true,captured_at:captured},'a'.repeat(64),{[id]:version}),/STALE_SNAPSHOT/);
    assert.equal((await apply('review-0001',scene(),{})).estado,'REVISION');
    assert.equal(await stock(),6);
    assert.equal((await pg.query("select has_function_privilege('anon','public.aplicar_evento(text,text,jsonb,jsonb,jsonb)','EXECUTE') as allowed")).rows[0].allowed,false);
    // Failure on the second line must roll back the successful first line.
    const id2='20000000-0000-4000-8000-000000000002';
    await pg.query('insert into inventario(id,producto,stock) values($1,$2,0)',[id2,'Vacío']);
    const multi = scene(); multi.productos.push({id:id2,cantidad:1,precio_costo:null});
    await assert.rejects(apply('sale-multi',multi),/INSUFFICIENT_STOCK/);
    assert.equal(await stock(),6);

    const pos = async (key,items,method='EFECTIVO',hash='c'.repeat(64)) =>
      (await pg.query('select registrar_venta_pos($1,$2,$3::jsonb,$4) as r',
        [key,hash,JSON.stringify(items),method])).rows[0].r;
    const posResult=await pos('pos-sale-0001',[{id,cantidad:2}]);
    assert.equal(posResult.estado,'APLICADO');
    assert.equal(Number(posResult.total),20);
    assert.equal(await stock(),4);
    assert.equal((await pos('pos-sale-0001',[{id,cantidad:2}])).duplicate,true);
    assert.equal(await stock(),4);
    assert.equal((await pg.query('select count(*)::int as n from venta_partidas')).rows[0].n,1);
    assert.equal((await pg.query('select count(*)::int as n from movimientos_inventario')).rows[0].n,1);
    await assert.rejects(pos('pos-sale-0002',[{id,cantidad:5}]),/INSUFFICIENT_STOCK/);
  } finally { await pg.close(); }
});

test('validación: no acepta UUID inventado y protege ventas no confirmadas', () => {
  assert.equal(validateScene(scene(),[{id}],{}).requiere_revision,true);
  assert.throws(()=>validateScene(scene(),[],{}),/MODEL_UNKNOWN/);
  const duplicate = scene(); duplicate.productos.push(duplicate.productos[0]);
  assert.throws(()=>validateScene(duplicate,[{id}],{}),/MODEL_UNKNOWN_OR_DUPLICATE/);
});

test('imagen: límites 1280x720, Base64 inválido y tipo inválido', async () => {
  const original=await sharp({create:{width:2000,height:1600,channels:3,background:'white'}}).png().toBuffer();
  const resized=await resizeImage(original);
  const info=await sharp(resized).metadata();
  assert.ok(info.width<=1280 && info.height<=720);
  assert.throws(()=>decodeBase64('!bad'),/INVALID_BASE64/);
  await assert.rejects(resizeImage(Buffer.from('not image')),/UNSUPPORTED_IMAGE/);
});

test('HTTP: auth, Base64, multipart, idempotencia, JSON corrupto', async () => {
  const config={CAMERA_API_KEY:'test'.repeat(10),CORS_ORIGINS:''};
  const bytes=await sharp({create:{width:20,height:20,channels:3,background:'white'}}).jpeg().toBuffer();
  let calls=0;
  const events=new Map();
  const db={lookup:async key=>events.get(key),catalog:async()=>[{id}],apply:async(key,hash,s)=>{
    const respuesta={estado:s.requiere_revision?'REVISION':'APLICADO'};
    events.set(key,{hash,respuesta}); return respuesta;
  }};
  const app=createApp({config,db,analyze:async()=>{calls++;return scene();}});
  await request(app).post('/api/cam-event').send({}).expect(401);
  const body={image:bytes.toString('base64'),transaction_confirmed:true};
  const send=()=>request(app).post('/api/cam-event').set('Authorization',`Bearer ${config.CAMERA_API_KEY}`).set('Idempotency-Key','http-0001').send(body);
  await send().expect(200); const retry=await send().expect(200);
  assert.equal(retry.body.duplicate,true); assert.equal(calls,1);
  await request(app).post('/api/cam-event').set('Authorization',`Bearer ${config.CAMERA_API_KEY}`)
    .set('Idempotency-Key','http-0002').field('transaction_confirmed','true').attach('image',bytes,'cam.jpg').expect(200);
  await request(app).post('/api/cam-event').set('Authorization',`Bearer ${config.CAMERA_API_KEY}`)
    .set('Content-Type','application/json').send('{oops').expect(400);
  await request(app).get('/healthz').expect(200);
});

test('HTTP: deadline aborta proveedor y no inicia escritura posterior', async () => {
  const config={CAMERA_API_KEY:'test'.repeat(10),CORS_ORIGINS:''};
  const bytes=await sharp({create:{width:20,height:20,channels:3,background:'white'}}).jpeg().toBuffer();
  let writes=0;
  const db={lookup:async()=>null,catalog:async()=>[{id}],apply:async()=>{writes++;return {};}};
  const analyze=async(image,meta,catalog,signal)=>{
    await new Promise(resolve=>signal.addEventListener('abort',resolve,{once:true}));
    return scene(); // incluso si el adaptador devuelve tarde, no debe hacer commit
  };
  const app=createApp({config,db,analyze});
  await request(app).post('/api/cam-event').set('Authorization',`Bearer ${config.CAMERA_API_KEY}`)
    .set('Idempotency-Key','timeout-0001').send({image:bytes.toString('base64'),transaction_confirmed:true}).expect(504);
  assert.equal(writes,0);
});

test('panel: sirve la interfaz y protege datos y altas de inventario', async () => {
  const config={CAMERA_API_KEY:'test'.repeat(10),CORS_ORIGINS:''};
  const product={id,producto:'Agua 1 L',marca:'Marca A',precio_costo:5,precio_venta:10,stock:4};
  const db={
    dashboard:async()=>({inventario:[product],ventas:[],facturas:[],alertas:[]}),
    addProduct:async value=>({...product,...value}),
    resolveAlert:async alertId=>({id:alertId,resuelto:true})
  };
  const app=createApp({config,db,analyze:async()=>scene()});
  const auth={Authorization:`Bearer ${config.CAMERA_API_KEY}`};
  const home=await request(app).get('/').expect(200);
  assert.match(home.text,/Entra a tu tienda/);
  await request(app).get('/api/dashboard').expect(401);
  const dashboard=await request(app).get('/api/dashboard').set(auth).expect(200);
  assert.equal(dashboard.body.inventario[0].producto,'Agua 1 L');
  await request(app).post('/api/inventory').set(auth).send({producto:''}).expect(400);
  const added=await request(app).post('/api/inventory').set(auth)
    .send({producto:'Refresco',marca:'A',precio_costo:8,precio_venta:13,stock:6}).expect(201);
  assert.equal(added.body.producto,'Refresco');
});

test('POS: catálogo protegido, venta validada e idempotente', async () => {
  const config={CAMERA_API_KEY:'test'.repeat(10),CORS_ORIGINS:''};
  const product={id,producto:'Agua 1 L',marca:'A',codigo_barras:'750100000001',precio_venta:10,stock:4,stock_minimo:3};
  let registered;
  const db={
    posCatalog:async barcode=>barcode && barcode!==product.codigo_barras?[]:[product],
    registerPosSale:async(key,hash,sale)=>{registered={key,hash,sale};return {estado:'APLICADO',total:20};}
  };
  const app=createApp({config,db,analyze:async()=>scene()});
  const auth={Authorization:`Bearer ${config.CAMERA_API_KEY}`};
  await request(app).get('/api/pos/catalog').expect(401);
  const catalog=await request(app).get('/api/pos/catalog?barcode=750100000001').set(auth).expect(200);
  assert.equal(catalog.body[0].id,id);
  await request(app).post('/api/pos/sales').set(auth).send({items:[]}).expect(400);
  const response=await request(app).post('/api/pos/sales').set(auth)
    .set('Idempotency-Key','pos-http-0001')
    .send({items:[{id,cantidad:2}],metodo_pago:'EFECTIVO'}).expect(201);
  assert.equal(response.body.total,20);
  assert.equal(registered.sale.items[0].cantidad,2);
  assert.match(registered.hash,/^[a-f0-9]{64}$/);
});
