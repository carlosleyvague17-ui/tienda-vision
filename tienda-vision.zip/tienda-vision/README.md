# Tienda Vision — Node.js + Express + Supabase + OpenAI

Backend completo para una tienda y un catálogo en MXN, con imágenes JPEG/PNG/WebP,
Base64 o multipart. Las operaciones de inventario, venta, factura, alerta y evento
se confirman juntas dentro de PostgreSQL. No almacena fotografías en disco.

## Alcance y límites reales

El proyecto está preparado para desplegar y probar. No se ha conectado a tus
credenciales ni certificado con tus cámaras reales. Las pruebas incluidas usan
PostgreSQL embebido (PGlite), HTTP con dependencias simuladas y Sharp real.
Debes validar precisión con tus productos, iluminación y documentos antes de
permitir operaciones automáticas sobre inventario real.

Render Free sirve para piloto: duerme tras 15 minutos sin tráfico y el arranque
puede tardar aproximadamente un minuto. Render desaconseja ese plan para
producción. El plazo de 10 segundos se aplica cuando Express recibe la petición;
no incluye la espera del proxy mientras arranca la instancia. La API de OpenAI
se factura por separado. No se garantiza latencia ni costo fijo por imagen.

Se usa `OPENAI_MODEL=gpt-4.1-mini`, que admite imágenes y Chat Completions. El
identificador es configurable. No se supone que `Astra` sea un alias que se pueda
enviar directamente: si cambias de modelo, verifica acceso y compatibilidad con
Chat Completions, imágenes, `detail:auto`, JSON mode y `max_completion_tokens`.

## Archivos

- `server.js`: aplicación, CORS, compresión, rate limit, errores y apagado.
- `routes/vision.js`: autenticación, parsing, deadline y orquestación.
- `services/openaiService.js`: prompt y llamada de visión.
- `services/dbService.js`: cliente Supabase y RPC atómica.
- `lib/config.js`, `lib/errors.js`, `lib/image.js`, `lib/validation.js`: configuración y validación.
- `schema.sql`: tablas, índices, trigger, función transaccional y permisos.
- `test/core.test.js`: pruebas automatizadas.
- `.env.example`, `package.json`, `package-lock.json`, `render.yaml`, `.gitignore`.

## Preparación local

1. Instala Node.js 22 o 24 y descomprime el proyecto.
2. Crea un proyecto Supabase. Ejecuta **todo** `schema.sql` en SQL Editor como
   administrador. Está pensado para una base nueva; no pretende migrar un esquema
   previo con tablas del mismo nombre. No crees políticas públicas de escritura.
3. Carga tu catálogo real. Los nombres deben incluir presentación/tamaño para
   distinguir variantes. La IA nunca crea productos desconocidos.

```sql
insert into public.inventario(producto, marca, precio_costo, precio_venta, stock)
values ('Agua natural 1 L', 'Marca de ejemplo', 8.50, 15.00, 20);
select id, producto, marca, stock from public.inventario;
```

4. Instala dependencias y configura variables:

```bash
npm ci
cp .env.example .env
openssl rand -hex 32
```

Copia el último resultado en `CAMERA_API_KEY` y edita el resto de `.env`.

| Variable | Uso |
|---|---|
| `PORT` | Puerto HTTP local; 10000 por defecto. Render lo proporciona. |
| `OPENAI_API_KEY` | Clave de un proyecto OpenAI con acceso y saldo. |
| `SUPABASE_URL` | URL HTTPS del proyecto. |
| `SUPABASE_KEY` | Clave de servidor `service_role`, nunca `anon` o publishable. |
| `CAMERA_API_KEY` | Secreto de al menos 32 caracteres para autenticar dispositivos. |
| `OPENAI_MODEL` | `gpt-4.1-mini` por defecto. |
| `CORS_ORIGINS` | Orígenes exactos separados por comas; vacío deshabilita CORS para navegadores. |
| `NODE_ENV` | `production` en despliegue. |

`CAMERA_API_KEY` es adicional a las cuatro variables solicitadas: evita que
cualquier visitante publique imágenes, consuma saldo o cambie inventario.
La clave Supabase y la clave OpenAI permanecen exclusivamente en el backend.

```bash
npm test
npm start
curl http://localhost:10000/healthz
```

Para desarrollo: `npm run dev`.

## Contrato HTTP

`POST /api/cam-event`

Cabeceras obligatorias:

```http
Authorization: Bearer TU_CAMERA_API_KEY
Idempotency-Key: cam01-evento-unico-000001
```

Usa un UUID o identificador persistente por **operación de negocio**, no por
fotograma ni por intento HTTP. Reenvía los mismos bytes de imagen, metadata y
clave si hay un timeout. Un evento repetido no descuenta ni recibe stock otra
vez. Un mismo identificador con distinto contenido devuelve 409. Si cámaras
diferentes observan una venta, el emisor debe coordinarlas para asignar la misma
operación y una captura canónica. Distintos identificadores de la misma venta
no pueden deduplicarse de forma fiable a partir de imágenes.

| Campo | Tipo JSON / multipart | Comportamiento |
|---|---|---|
| `image` | Cadena Base64 / archivo binario | Obligatorio; máximo 6 MiB decodificados. Data URI JPEG/PNG/WebP también aceptada. |
| `camera_type` | Cadena | Opcional: `mostrador`, `anaquel` o `factura`. |
| `transaction_confirmed` | Booleano / `true` o `false` | Por defecto false. El POS/sensor de operación debe confirmar la venta. |
| `receipt_confirmed` | Booleano / `true` o `false` | Por defecto false. Confirma que llegó la mercancía; una factura sola no lo prueba. |
| `inventory_complete` | Booleano / `true` o `false` | Por defecto false. Confirma que se ve toda la existencia de cada SKU contado. |
| `captured_at` | Fecha ISO 8601 con zona horaria | Para INVENTARIO: captura de los últimos 60 segundos y posterior al último movimiento del SKU. |
| `product_ids` | Array de UUID / cadena JSON del array | Opcional, máximo 100; limita el catálogo enviado al modelo. |

Los booleanos son afirmaciones del sistema autenticado, no verificaciones
visuales. No los actives permanentemente en una cámara que emite fotogramas
continuos. Una imagen borrosa o ambigua produce revisión aunque estén activos.
Un anaquel no representa el almacén: `inventory_complete=true` sólo es válido si
el encuadre cubre todas las unidades del SKU o el catálogo representa esa zona.
Para varias tiendas/zonas hay que ampliar el modelo con ubicaciones y permisos.

### Multipart: venta confirmada

```bash
curl --max-time 15 -X POST http://localhost:10000/api/cam-event \
  -H 'Authorization: Bearer TU_CAMERA_API_KEY' \
  -H 'Idempotency-Key: caja01-venta-000001' \
  -F 'image=@venta.jpg' \
  -F 'camera_type=mostrador' \
  -F 'transaction_confirmed=true'
```

### Multipart: factura recibida

```bash
curl --max-time 15 -X POST http://localhost:10000/api/cam-event \
  -H 'Authorization: Bearer TU_CAMERA_API_KEY' \
  -H 'Idempotency-Key: recepcion-000001' \
  -F 'image=@factura.jpg' \
  -F 'camera_type=factura' \
  -F 'receipt_confirmed=true'
```

### Base64 desde un archivo

Este ejemplo crea JSON correcto sin depender de las diferencias de `base64`
entre sistemas. Añade `product_ids` con UUID reales si necesitas acotar catálogo.

```bash
python3 - <<'PY'
import base64, json
from pathlib import Path
body = {
    'image': base64.b64encode(Path('venta.jpg').read_bytes()).decode(),
    'camera_type': 'mostrador',
    'transaction_confirmed': True
}
Path('request.json').write_text(json.dumps(body))
PY
curl --max-time 15 -X POST http://localhost:10000/api/cam-event \
  -H 'Authorization: Bearer TU_CAMERA_API_KEY' \
  -H 'Idempotency-Key: caja01-venta-000002' \
  -H 'Content-Type: application/json' \
  --data-binary @request.json
```

ESP32-CAM puede usar multipart para evitar el incremento de memoria de Base64.
Usa HTTPS con validación de certificado en Render; conserva el evento pendiente
hasta recibir confirmación. Este proyecto entrega el backend, no firmware.

### Estados de respuesta

- **200 APLICADO**: cambios confirmados o replay de un evento aplicado.
- **202 REVISION**: guardado en `eventos` y `alertas`; no se modificó stock. No
  existe trabajador automático ni endpoint de aprobación. Revisión desde un
  entorno administrativo; tras verificar, realiza una operación corregida con
  nueva clave y marca la alerta como resuelta. Repetir la clave conserva revisión.
- **200 con `duplicate:true`**: devuelve el resultado ya guardado; inspecciona
  `estado`, porque también puede ser el replay de una revisión.
- **400/401/413/415**: metadata/JSON, autenticación, tamaño o imagen inválida.
- **409**: clave reutilizada, factura duplicada, stock insuficiente o conteo viejo.
- **422**: catálogo vacío/desconocido, selección necesaria o total no conciliado.
- **429**: límite global de 30 peticiones por minuto de esta instancia.
- **502/503**: respuesta inválida, proveedor no disponible, base no disponible o
  capacidad ocupada. Respeta `Retry-After` cuando exista.
- **504**: deadline de 10 segundos. Reintenta con la MISMA clave y contenido.

El aborto de HTTP no garantiza que PostgreSQL haya cancelado un commit en curso.
Un timeout puede tener resultado incierto; repetir la misma clave recupera el
resultado o aplica una sola vez. Nunca generes otra clave para ese reintento.
La consulta previa evita costo OpenAI en replays ya confirmados; dos peticiones
simultáneas todavía pueden pagar dos inferencias, aunque sólo haya un commit.

Ejemplo de revisión:

```json
{
  "evento_id": "cam01-evento-unico-000001",
  "estado": "REVISION",
  "tipo": "TRANSACCION",
  "motivo": "Venta no confirmada por el origen",
  "duplicate": false
}
```

## Reglas de negocio

- TRANSACCION resta unidades, calcula total con `precio_venta` de la base en el
  momento del commit y registra producto, marca, cantidad y precio aplicado.
  La IA no fija precios. No implementa descuentos, devoluciones ni emisión fiscal.
- DOC_RECEPCION suma unidades, conserva líneas/precios y proveedor/folio, y
  actualiza costo a la última compra. Exige total igual a suma de líneas. Facturas
  con IVA separado, descuentos globales, flete o moneda distinta requieren revisión
  y ampliación explícita del modelo; no se inventa una conciliación contable.
  La tabla `facturas` registra documentos recibidos, no emite CFDI ante el SAT.
- INVENTARIO ajusta sólo los SKU explícitos, incluidos ceros inequívocos. No
  pone en cero productos omitidos. Rechaza cambios si hubo movimiento posterior
  a la captura o si cambió la versión mientras la IA trabajaba.
- Stock menor que 3 genera una alerta abierta por producto. Una reposición o
  conteo a 3 o más resuelve esa alerta. Ningún stock puede ser negativo.
- La RPC serializa las escrituras de esta tienda y las confirma atómicamente.
  Los locks existen sólo durante el commit SQL, no durante la llamada a OpenAI.
- RLS y permisos bloquean acceso de `anon` y `authenticated`. `service_role`
  puede operar; por eso nunca debe distribuirse a cámaras ni navegadores.

## Costos, memoria y timeout

- Sharp valida formato real y limita entrada a 20 megapíxeles; máximo de archivo
  6 MiB, JSON 9 MiB; no se aceptan GIF, PDF, SVG ni animaciones.
- Reorienta por EXIF, elimina metadata, ajusta dentro de 1280×720 sin deformar ni
  ampliar, y convierte a JPEG calidad 80.
- OpenAI recibe exactamente `detail: "auto"` y
  `response_format: { "type": "json_object" }`.
- JSON mode garantiza formato JSON, no fidelidad al esquema ni a la escena.
  Zod valida tipos, UUID conocidos, duplicados y reglas adicionales.
- Máximo 1800 tokens de salida; una salida truncada no modifica stock. Para
  facturas extensas, procesa documentos más pequeños y coordina sus identidades;
  este endpoint está limitado a 50 SKU por evento y no implementa paginación de factura.
- Catálogo máximo de 100 SKU, sin precios ni stock en el prompt. Si hay más,
  especifica `product_ids` según cámara/zona para mantener bajo el costo.
- Dos trabajos simultáneos como máximo, Sharp con un hilo y caché deshabilitada.
  Rate limit y capacidad son locales a una instancia; si escalas, usa control
  distribuido y credenciales individuales por dispositivo/tienda.
- Deadline HTTP de 10 segundos desde entrada al endpoint; cliente OpenAI con
  timeout de 10000 ms y sin reintentos internos. Un 504 es un límite, no una
  promesa de que la inferencia terminará a tiempo. No hay cola durable interna.
- Los logs excluyen imágenes, secretos y texto OCR. Configura retención de
  `eventos`, `facturas` y alertas según tus necesidades. No borres eventos mientras
  sus identificadores puedan volver a enviarse: son la memoria de idempotencia.

## Render paso a paso

1. Ejecuta `schema.sql` y carga el catálogo en Supabase.
2. Sube el contenido de esta carpeta a un repositorio Git, incluyendo
   `package-lock.json`. No subas `.env` ni fotografías de prueba.
3. En Render selecciona **New → Web Service**, conecta ese repositorio y elige
   **Node** y **Free**. Si está en una subcarpeta, configura Root Directory.
4. Usa **Build Command:** `npm ci --omit=dev` y **Start Command:** `npm start`.
5. Configura `NODE_VERSION=22`, `NODE_ENV=production`, `OPENAI_API_KEY`,
   `SUPABASE_URL`, `SUPABASE_KEY`, `CAMERA_API_KEY` y `OPENAI_MODEL=gpt-4.1-mini`.
   Opcionalmente configura `CORS_ORIGINS`. Deja el `PORT` que asigna Render;
   el servidor escucha en `0.0.0.0`.
6. Define **Health Check Path:** `/healthz`. Es un chequeo de proceso, no una
   prueba de conectividad a OpenAI/Supabase.
7. Despliega y verifica `https://TU-SERVICIO.onrender.com/healthz`. Prueba los
   ejemplos sustituyendo la URL local y las credenciales.
8. Alternativa: crea un Blueprint desde `render.yaml`; solicitará secretos y
   generará `CAMERA_API_KEY`. Copia esa clave desde la configuración al emisor.
9. En los dispositivos implementa reintentos con espera exponencial y jitter,
   límite de intentos y cola persistente del lado del emisor. Un arranque en frío
   puede superar el timeout; conserva siempre la misma identidad del evento.

Para producción continua, usa una instancia sin suspensión y verifica carga,
latencia de región, cuotas, copias de seguridad y precisión visual en tu entorno.
El código no puede convertir un plan gratuito con suspensión en un servicio con SLA.

## Fuentes oficiales

- Visión y `detail`: https://developers.openai.com/api/docs/guides/images-vision
- JSON mode y sus límites: https://developers.openai.com/api/docs/guides/structured-outputs
- Modelo predeterminado: https://developers.openai.com/api/docs/models/gpt-4.1-mini
- Funciones de base de datos: https://supabase.com/docs/guides/database/functions
- Restricciones de Render Free: https://render.com/docs/free
