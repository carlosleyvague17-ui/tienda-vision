-- Ejecutar una vez en un proyecto Supabase nuevo, desde SQL Editor como postgres.
-- Para cambios posteriores usar migraciones; este archivo no borra datos.
begin;
create table public.inventario (
  id uuid primary key default gen_random_uuid(),
  producto text not null check (length(producto) between 1 and 200),
  marca text not null default '' check (length(marca) <= 100),
  precio_costo numeric(12,2) not null default 0 check (precio_costo >= 0),
  precio_venta numeric(12,2) not null default 0 check (precio_venta >= 0),
  stock integer not null default 0 check (stock >= 0),
  actualizado_en timestamptz not null default clock_timestamp()
);
create table public.eventos (
  id text primary key check (length(id) between 8 and 128),
  fecha timestamptz not null default clock_timestamp(),
  hash text not null check (hash ~ '^[a-f0-9]{64}$'),
  escena jsonb not null,
  metadata jsonb not null,
  respuesta jsonb not null
);
create table public.ventas (
  id uuid primary key default gen_random_uuid(),
  fecha timestamptz not null default clock_timestamp(),
  productos_json jsonb not null,
  total_venta numeric(14,2) not null check (total_venta >= 0),
  evento_id text not null unique references public.eventos(id) deferrable initially deferred
);
create table public.facturas (
  id uuid primary key default gen_random_uuid(),
  fecha timestamptz not null default clock_timestamp(),
  proveedor text not null,
  total_factura numeric(14,2) not null check (total_factura >= 0),
  numero_documento text not null,
  productos_json jsonb not null,
  evento_id text not null unique references public.eventos(id) deferrable initially deferred
);
-- Impide recibir dos veces la misma factura incluso con otra clave de evento.
create unique index factura_documento_unico on public.facturas
  (lower(btrim(proveedor)), lower(btrim(numero_documento)));
create table public.alertas (
  id uuid primary key default gen_random_uuid(),
  fecha timestamptz not null default clock_timestamp(),
  mensaje text not null,
  resuelto boolean not null default false,
  producto_id uuid references public.inventario(id),
  evento_id text references public.eventos(id) deferrable initially deferred
);
create unique index alerta_stock_abierta on public.alertas(producto_id)
  where resuelto = false and producto_id is not null;
create index ventas_fecha on public.ventas(fecha);
create index facturas_fecha on public.facturas(fecha);
create index eventos_fecha on public.eventos(fecha);

create function public.marcar_actualizacion() returns trigger
language plpgsql set search_path = '' as $$
begin
  new.actualizado_en := clock_timestamp();
  return new;
end;
$$;
create trigger inventario_version before update on public.inventario
  for each row execute function public.marcar_actualizacion();

create function public.aplicar_evento(
  p_id text, p_hash text, p_scene jsonb, p_meta jsonb, p_versions jsonb
) returns jsonb
language plpgsql security invoker set search_path = ''
set lock_timeout = '2s' set statement_timeout = '5s'
as $$
declare
  previo public.eventos%rowtype;
  item jsonb;
  producto public.inventario%rowtype;
  tipo text := p_scene->>'tipo';
  cantidad integer;
  costo numeric(12,2);
  nuevo_stock integer;
  total numeric(14,2) := 0;
  lineas jsonb := '[]'::jsonb;
  resultado jsonb;
  revision boolean;
begin
  if p_id is null or p_id !~ '^[a-zA-Z0-9_.:-]{8,128}$' or
     p_hash is null or p_hash !~ '^[a-f0-9]{64}$' then
    raise exception 'INVALID_EVENT';
  end if;
  -- Serializa commits de esta tienda. No se sostiene ningún lock durante la IA.
  perform pg_advisory_xact_lock(817344012);
  select * into previo from public.eventos where id = p_id;
  if found then
    if previo.hash <> p_hash then raise exception 'IDEMPOTENCY_CONFLICT'; end if;
    return previo.respuesta || jsonb_build_object('duplicate', true);
  end if;
  if tipo is null or tipo not in ('TRANSACCION','INVENTARIO','DOC_RECEPCION') or
     jsonb_typeof(p_scene->'productos') is distinct from 'array' or
     jsonb_typeof(p_scene->'requiere_revision') is distinct from 'boolean' then
    raise exception 'INVALID_EVENT';
  end if;
  if jsonb_array_length(p_scene->'productos') > 50 then raise exception 'INVALID_EVENT'; end if;
  revision := (p_scene->>'requiere_revision')::boolean;
  if tipo = 'TRANSACCION' and (p_meta->>'transaction_confirmed') is distinct from 'true' then revision := true; end if;
  if tipo = 'DOC_RECEPCION' and (p_meta->>'receipt_confirmed') is distinct from 'true' then revision := true; end if;
  if tipo = 'INVENTARIO' and (p_meta->>'inventory_complete') is distinct from 'true' then revision := true; end if;
  if jsonb_array_length(p_scene->'productos') = 0 then revision := true; end if;
  if revision then
    resultado := jsonb_build_object('evento_id',p_id,'estado','REVISION','tipo',tipo,
      'motivo',p_scene->>'motivo','duplicate',false);
    insert into public.eventos(id,hash,escena,metadata,respuesta) values(p_id,p_hash,p_scene,p_meta,resultado);
    insert into public.alertas(mensaje,evento_id)
      values('Revisión visual pendiente: ' || coalesce(p_scene->>'motivo','Sin detalle'),p_id);
    return resultado;
  end if;
  if exists(select 1 from jsonb_array_elements(p_scene->'productos') as x
    group by x->>'id' having count(*) > 1) then raise exception 'INVALID_EVENT'; end if;
  if tipo = 'DOC_RECEPCION' then
    if coalesce(length(btrim(p_scene->>'proveedor')),0) = 0 or
       coalesce(length(btrim(p_scene->>'numero_documento')),0) = 0 or
       coalesce(p_scene->>'total_factura','') !~ '^\d{1,8}\.\d{2}$' then raise exception 'INVALID_EVENT'; end if;
    if exists(select 1 from public.facturas where lower(btrim(proveedor)) = lower(btrim(p_scene->>'proveedor'))
      and lower(btrim(numero_documento)) = lower(btrim(p_scene->>'numero_documento'))) then
      raise exception 'DUPLICATE_DOCUMENT';
    end if;
  end if;
  -- También serializa escrituras administrativas que no usan esta RPC.
  lock table public.inventario in share row exclusive mode;
  for item in select value from jsonb_array_elements(p_scene->'productos') order by value->>'id' loop
    if coalesce(item->>'cantidad','') !~ '^\d{1,6}$' then raise exception 'INVALID_EVENT'; end if;
    cantidad := (item->>'cantidad')::integer;
    if cantidad > 100000 or (tipo <> 'INVENTARIO' and cantidad = 0) then raise exception 'INVALID_EVENT'; end if;
    select * into producto from public.inventario where id = (item->>'id')::uuid for update;
    if not found then raise exception 'UNKNOWN_PRODUCT'; end if;
    if tipo = 'TRANSACCION' then
      if producto.stock < cantidad then raise exception 'INSUFFICIENT_STOCK'; end if;
      nuevo_stock := producto.stock - cantidad;
      total := total + cantidad * producto.precio_venta;
      lineas := lineas || jsonb_build_array(jsonb_build_object('id',producto.id,'producto',producto.producto,
        'marca',producto.marca,'cantidad',cantidad,'precio_venta',producto.precio_venta));
    elsif tipo = 'DOC_RECEPCION' then
      if coalesce(item->>'precio_costo','') !~ '^\d{1,8}\.\d{2}$' then raise exception 'INVALID_EVENT'; end if;
      costo := (item->>'precio_costo')::numeric;
      nuevo_stock := producto.stock + cantidad;
      total := total + cantidad * costo;
      lineas := lineas || jsonb_build_array(jsonb_build_object('id',producto.id,'producto',producto.producto,
        'marca',producto.marca,'cantidad',cantidad,'precio_costo',costo));
      -- Política explícita: costo de última compra, no promedio ponderado.
      update public.inventario set precio_costo = costo where id = producto.id;
    else
      if p_meta->>'captured_at' is null or
         (p_meta->>'captured_at')::timestamptz < clock_timestamp() - interval '60 seconds' or
         (p_meta->>'captured_at')::timestamptz > clock_timestamp() + interval '5 seconds' or
         (p_meta->>'captured_at')::timestamptz < producto.actualizado_en or
         (p_versions->>producto.id::text)::timestamptz is distinct from producto.actualizado_en then
        raise exception 'STALE_SNAPSHOT';
      end if;
      nuevo_stock := cantidad;
      lineas := lineas || jsonb_build_array(jsonb_build_object('id',producto.id,
        'stock_anterior',producto.stock,'stock_nuevo',nuevo_stock));
    end if;
    update public.inventario set stock = nuevo_stock where id = producto.id;
    if nuevo_stock < 3 then
      insert into public.alertas(mensaje,producto_id,evento_id)
        values('Stock bajo: ' || producto.producto || ' (' || nuevo_stock || ')',producto.id,p_id)
        on conflict (producto_id) where resuelto = false and producto_id is not null do nothing;
    else
      update public.alertas set resuelto = true where producto_id = producto.id and resuelto = false;
    end if;
  end loop;
  if tipo = 'TRANSACCION' then
    insert into public.ventas(productos_json,total_venta,evento_id) values(lineas,total,p_id);
  elsif tipo = 'DOC_RECEPCION' then
    if total <> (p_scene->>'total_factura')::numeric then raise exception 'INVOICE_TOTAL_MISMATCH'; end if;
    insert into public.facturas(proveedor,total_factura,numero_documento,productos_json,evento_id)
      values(btrim(p_scene->>'proveedor'),total,btrim(p_scene->>'numero_documento'),lineas,p_id);
  end if;
  resultado := jsonb_build_object('evento_id',p_id,'estado','APLICADO','tipo',tipo,
    'productos',lineas,'total',case when tipo='INVENTARIO' then null else total end,'duplicate',false);
  insert into public.eventos(id,hash,escena,metadata,respuesta) values(p_id,p_hash,p_scene,p_meta,resultado);
  return resultado;
end;
$$;

-- Ninguna tabla financiera es pública. El backend usa service_role, que evita RLS.
alter table public.inventario enable row level security;
alter table public.ventas enable row level security;
alter table public.facturas enable row level security;
alter table public.alertas enable row level security;
alter table public.eventos enable row level security;
revoke all on public.inventario, public.ventas, public.facturas, public.alertas, public.eventos from public, anon, authenticated;
grant select, insert, update, delete on public.inventario, public.ventas, public.facturas, public.alertas, public.eventos to service_role;
revoke all on function public.aplicar_evento(text,text,jsonb,jsonb,jsonb) from public, anon, authenticated;
grant execute on function public.aplicar_evento(text,text,jsonb,jsonb,jsonb) to service_role;
revoke all on function public.marcar_actualizacion() from public, anon, authenticated;
commit;
