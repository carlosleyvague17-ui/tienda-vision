const $ = selector => document.querySelector(selector);
const $$ = selector => [...document.querySelectorAll(selector)];
const state = { key: sessionStorage.getItem('tiendaVisionKey') || '', data: null };
const money = value => new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN' }).format(Number(value || 0));
const date = value => new Intl.DateTimeFormat('es-MX', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value));
const escapeText = value => String(value ?? '').replace(/[&<>'"]/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[char]));

async function api(path, options = {}) {
  const headers = new Headers(options.headers || {});
  headers.set('Authorization', `Bearer ${state.key}`);
  if (options.body && !(options.body instanceof FormData)) headers.set('Content-Type', 'application/json');
  const response = await fetch(path, { ...options, headers });
  const payload = await response.json().catch(() => ({}));
  if (response.status === 401) logout('La clave no es correcta.');
  if (!response.ok) throw new Error(payload.error || `Error ${response.status}`);
  return payload;
}

function toast(message) {
  const el = $('#toast'); el.textContent = message; el.classList.add('show');
  clearTimeout(toast.timer); toast.timer = setTimeout(() => el.classList.remove('show'), 2600);
}

function logout(message = '') {
  state.key = ''; state.data = null; sessionStorage.removeItem('tiendaVisionKey');
  $('#dashboardView').classList.add('hidden'); $('#logoutButton').classList.add('hidden');
  $('#loginView').classList.remove('hidden'); $('#apiKey').value = '';
  $('#loginError').textContent = message;
}

async function login(key) {
  state.key = key.trim(); $('#loginError').textContent = 'Comprobando…';
  try {
    await loadDashboard();
    sessionStorage.setItem('tiendaVisionKey', state.key);
    $('#loginView').classList.add('hidden'); $('#dashboardView').classList.remove('hidden');
    $('#logoutButton').classList.remove('hidden'); $('#loginError').textContent = '';
  } catch (error) {
    if (state.key) $('#loginError').textContent = error.message === 'Failed to fetch' ? 'No se pudo conectar con el servidor.' : 'No se pudo entrar. Revisa la clave.';
  }
}

async function loadDashboard() {
  state.data = await api('/api/dashboard');
  render();
}

function render() {
  const { inventario, ventas, facturas, alertas } = state.data;
  const openAlerts = alertas.filter(item => !item.resuelto);
  $('#productCount').textContent = inventario.length;
  $('#stockTotal').textContent = inventario.reduce((sum, item) => sum + Number(item.stock), 0).toLocaleString('es-MX');
  $('#salesTotal').textContent = money(ventas.reduce((sum, item) => sum + Number(item.total_venta), 0));
  $('#alertCount').textContent = openAlerts.length;
  $('#lastUpdate').textContent = `Actualizado ${new Intl.DateTimeFormat('es-MX', { timeStyle: 'short' }).format(new Date())}`;

  $('#inventoryRows').innerHTML = inventario.map(item => `<tr><td><strong>${escapeText(item.producto)}</strong></td><td>${escapeText(item.marca || '—')}</td><td>${money(item.precio_costo)}</td><td>${money(item.precio_venta)}</td><td><span class="stock ${item.stock < 3 ? 'low' : ''}">${item.stock}</span></td></tr>`).join('');
  $('#inventoryEmpty').classList.toggle('hidden', inventario.length > 0);
  $('#inventoryRows').closest('.table-wrap').classList.toggle('hidden', inventario.length === 0);

  $('#salesRows').innerHTML = ventas.map(item => `<tr><td>${date(item.fecha)}</td><td class="products-cell">${escapeText((item.productos_json || []).map(p => `${p.cantidad} × ${p.producto}`).join(', ') || '—')}</td><td><strong>${money(item.total_venta)}</strong></td></tr>`).join('');
  $('#salesEmpty').classList.toggle('hidden', ventas.length > 0);
  $('#salesRows').closest('.table-wrap').classList.toggle('hidden', ventas.length === 0);

  $('#invoiceRows').innerHTML = facturas.map(item => `<tr><td>${date(item.fecha)}</td><td><strong>${escapeText(item.proveedor)}</strong></td><td>${escapeText(item.numero_documento)}</td><td><strong>${money(item.total_factura)}</strong></td></tr>`).join('');
  $('#invoicesEmpty').classList.toggle('hidden', facturas.length > 0);
  $('#invoiceRows').closest('.table-wrap').classList.toggle('hidden', facturas.length === 0);

  $('#alertList').innerHTML = openAlerts.map(item => `<article class="alert-item"><span class="alert-symbol">!</span><div class="alert-copy"><strong>${escapeText(item.mensaje)}</strong><small>${date(item.fecha)}</small></div><button class="button ghost resolve-alert" data-id="${item.id}" type="button">Resolver</button></article>`).join('');
  $('#alertsEmpty').classList.toggle('hidden', openAlerts.length > 0);
}

function switchTab(id) {
  $$('.tab').forEach(el => el.classList.toggle('active', el.dataset.tab === id));
  $$('.tab-panel').forEach(el => el.classList.toggle('active', el.id === id));
}

$('#loginForm').addEventListener('submit', event => { event.preventDefault(); login($('#apiKey').value); });
$('#toggleKey').addEventListener('click', () => { const input = $('#apiKey'); input.type = input.type === 'password' ? 'text' : 'password'; $('#toggleKey').textContent = input.type === 'password' ? 'Ver' : 'Ocultar'; });
$('#logoutButton').addEventListener('click', () => logout());
$('#refreshButton').addEventListener('click', async event => { event.currentTarget.disabled = true; try { await loadDashboard(); toast('Datos actualizados'); } catch (error) { toast(`Error: ${error.message}`); } finally { event.currentTarget.disabled = false; } });
$$('.tab').forEach(tab => tab.addEventListener('click', () => switchTab(tab.dataset.tab)));

$('#showProductForm').addEventListener('click', () => $('#productForm').classList.remove('hidden'));
$('#cancelProduct').addEventListener('click', () => { $('#productForm').reset(); $('#productForm').classList.add('hidden'); });
$('#productForm').addEventListener('submit', async event => {
  event.preventDefault(); const form = event.currentTarget; const button = form.querySelector('[type=submit]'); button.disabled = true;
  const values = Object.fromEntries(new FormData(form));
  const body = { ...values, precio_costo: Number(values.precio_costo), precio_venta: Number(values.precio_venta), stock: Number(values.stock) };
  try { await api('/api/inventory', { method: 'POST', body: JSON.stringify(body) }); form.reset(); form.classList.add('hidden'); await loadDashboard(); toast('Producto agregado'); }
  catch (error) { $('#productMessage').textContent = `No se pudo guardar: ${error.message}`; $('#productMessage').classList.add('error'); }
  finally { button.disabled = false; }
});

$('#alertList').addEventListener('click', async event => {
  const button = event.target.closest('.resolve-alert'); if (!button) return; button.disabled = true;
  try { await api(`/api/alerts/${button.dataset.id}/resolve`, { method: 'PATCH' }); await loadDashboard(); toast('Alerta resuelta'); }
  catch (error) { toast(`Error: ${error.message}`); button.disabled = false; }
});

$('#imageInput').addEventListener('change', event => {
  const file = event.target.files[0]; if (!file) return;
  $('#imageLabel').textContent = file.name; const preview = $('#imagePreview');
  const reader = new FileReader();
  reader.addEventListener('load', () => { preview.src = reader.result; preview.classList.remove('hidden'); $('.upload-zone label').classList.add('hidden'); });
  reader.readAsDataURL(file);
});
$('#imagePreview').addEventListener('click', () => $('#imageInput').click());

$('#captureForm').addEventListener('submit', async event => {
  event.preventDefault(); const button = $('#processButton'); const message = $('#captureMessage');
  const file = $('#imageInput').files[0]; if (!file) return;
  const type = $('#cameraType').value; const confirmed = $('#confirmed').checked;
  const data = new FormData(); data.set('image', file); data.set('camera_type', type);
  data.set('transaction_confirmed', String(type === 'mostrador' && confirmed));
  data.set('receipt_confirmed', String(type === 'factura' && confirmed));
  data.set('inventory_complete', String(type === 'anaquel' && confirmed));
  if (type === 'anaquel') data.set('captured_at', new Date().toISOString());
  button.disabled = true; button.textContent = 'Analizando…'; message.textContent = 'La IA está revisando la imagen.'; message.classList.remove('error');
  try {
    const result = await api('/api/cam-event', { method: 'POST', headers: { 'Idempotency-Key': crypto.randomUUID() }, body: data });
    message.textContent = result.estado === 'APLICADO' ? 'Cambio aplicado correctamente.' : `Requiere revisión: ${result.motivo || 'verifica la imagen'}`;
    await loadDashboard(); switchTab(result.estado === 'APLICADO' ? (type === 'mostrador' ? 'sales' : type === 'factura' ? 'invoices' : 'inventory') : 'alerts');
    toast(result.estado === 'APLICADO' ? 'Operación aplicada' : 'Evento enviado a revisión');
  } catch (error) { message.textContent = `No se pudo procesar: ${error.message}`; message.classList.add('error'); }
  finally { button.disabled = false; button.textContent = 'Analizar y actualizar'; }
});

fetch('/healthz').then(r => { if (!r.ok) throw new Error(); }).catch(() => { $('#serverStatus').textContent = 'Sin conexión'; $('.status-dot').style.background = '#e15c5c'; });
if (state.key) login(state.key);
