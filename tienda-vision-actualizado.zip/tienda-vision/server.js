import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import { rateLimit } from 'express-rate-limit';
import { randomUUID } from 'node:crypto';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { loadConfig } from './lib/config.js';
import { AppError } from './lib/errors.js';
import { createVisionRouter } from './routes/vision.js';
import { createDashboardRouter } from './routes/dashboard.js';
import { createDbService } from './services/dbService.js';
import { createVisionService } from './services/openaiService.js';
export function createApp(deps) {
  const app = express();
  app.disable('x-powered-by');
  // Do not trust arbitrary forwarded IPs. Single-instance global rate limit below.
  const origins = deps.config.CORS_ORIGINS.split(',').map(s => s.trim()).filter(Boolean);
  app.use(helmet(), compression(), cors({ origin: origins, methods: ['POST', 'GET', 'PATCH'],
    allowedHeaders: ['Content-Type', 'Authorization', 'Idempotency-Key'] }));
  app.use((req, res, next) => {
    req.requestId = randomUUID();
    res.set('X-Request-Id', req.requestId).set('Cache-Control', 'no-store'); next();
  });
  app.use(express.static(fileURLToPath(new URL('./public', import.meta.url)), {
    extensions: ['html'], maxAge: '1h', etag: true
  }));
  app.get('/healthz', (req, res) => res.json({ status: 'ok' }));
  app.use('/api', rateLimit({ windowMs: 60_000, limit: 30,
    keyGenerator: () => 'single-store', standardHeaders: 'draft-8', legacyHeaders: false,
    message: { error: 'RATE_LIMITED' }
  }), createVisionRouter(deps), createDashboardRouter(deps));
  app.use((req, res, next) => next(new AppError(404, 'NOT_FOUND')));
  app.use((err, req, res, next) => {
    req.release?.();
    if (res.headersSent) return;
    const isUpload = err.name === 'MulterError';
    const status = err.status || (isUpload ? (err.code === 'LIMIT_FILE_SIZE' ? 413 : 400) :
      req.deadline?.signal.aborted ? 504 : 500);
    const code = err instanceof AppError ? err.code :
      isUpload ? err.code : err.type === 'entity.too.large' ? 'BODY_TOO_LARGE' :
      err.type === 'entity.parse.failed' ? 'INVALID_JSON' : status === 504 ? 'TIMEOUT' : 'REQUEST_FAILED';
    // Never log images, authorization headers, provider payloads or keys.
    console.error(JSON.stringify({ request_id: req.requestId, status, code }));
    res.status(status).json({ error: code, request_id: req.requestId });
  });
  return app;
}
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const config = loadConfig();
  const app = createApp({ config, db: createDbService(config), analyze: createVisionService(config) });
  const server = app.listen(config.PORT, '0.0.0.0', () => console.log(`Listening on ${config.PORT}`));
  server.requestTimeout = 10_000;
  server.headersTimeout = 10_000;
  server.keepAliveTimeout = 5000;
  for (const sig of ['SIGTERM', 'SIGINT']) process.once(sig, () => {
    server.close(() => process.exit(0));
    setTimeout(() => { server.closeAllConnections(); process.exit(1); }, 12_000).unref();
  });
}
