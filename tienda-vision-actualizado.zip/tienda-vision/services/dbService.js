import { createClient } from '@supabase/supabase-js';
import { AppError } from '../lib/errors.js';
export function createDbService(config) {
  const db = createClient(config.SUPABASE_URL, config.SUPABASE_KEY, {
    auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false }
  });
  function unwrap({ data, error }, signal) {
    if (error) {
      if (signal.aborted) throw new AppError(504, 'DATABASE_TIMEOUT_RETRY_SAME_KEY');
      const conflicts = ['IDEMPOTENCY_CONFLICT', 'INSUFFICIENT_STOCK', 'STALE_SNAPSHOT', 'DUPLICATE_DOCUMENT'];
      const invalid = ['INVALID_EVENT', 'UNKNOWN_PRODUCT', 'INVOICE_TOTAL_MISMATCH'];
      if (conflicts.includes(error.message)) throw new AppError(409, error.message);
      if (invalid.includes(error.message)) throw new AppError(422, error.message);
      throw new AppError(503, 'DATABASE_UNAVAILABLE');
    }
    return data;
  }
  return {
    async dashboard(signal) {
      const [inventario, ventas, facturas, alertas] = await Promise.all([
        db.from('inventario').select('id,producto,marca,precio_costo,precio_venta,stock,actualizado_en')
          .order('producto').limit(500).abortSignal(signal),
        db.from('ventas').select('id,fecha,productos_json,total_venta').order('fecha', { ascending: false })
          .limit(50).abortSignal(signal),
        db.from('facturas').select('id,fecha,proveedor,total_factura,numero_documento,productos_json')
          .order('fecha', { ascending: false }).limit(50).abortSignal(signal),
        db.from('alertas').select('id,fecha,mensaje,resuelto,producto_id').order('fecha', { ascending: false })
          .limit(100).abortSignal(signal)
      ]);
      return {
        inventario: unwrap(inventario, signal),
        ventas: unwrap(ventas, signal),
        facturas: unwrap(facturas, signal),
        alertas: unwrap(alertas, signal)
      };
    },
    async addProduct(product, signal) {
      return unwrap(await db.from('inventario').insert(product)
        .select('id,producto,marca,precio_costo,precio_venta,stock,actualizado_en')
        .single().abortSignal(signal), signal);
    },
    async resolveAlert(id, signal) {
      const row = unwrap(await db.from('alertas').update({ resuelto: true }).eq('id', id)
        .select('id,resuelto').maybeSingle().abortSignal(signal), signal);
      if (!row) throw new AppError(404, 'ALERT_NOT_FOUND');
      return row;
    },
    async lookup(key, signal) {
      return unwrap(await db.from('eventos').select('hash,respuesta').eq('id', key)
        .maybeSingle().abortSignal(signal), signal);
    },
    async catalog(ids, signal) {
      let query = db.from('inventario').select('id,producto,marca,actualizado_en').order('id').limit(101);
      if (ids) query = query.in('id', ids);
      const rows = unwrap(await query.abortSignal(signal), signal);
      if (!rows.length) throw new AppError(422, 'EMPTY_CATALOG');
      if (rows.length > 100) throw new AppError(422, 'PROVIDE_PRODUCT_IDS_MAX_100');
      if (ids && rows.length !== new Set(ids).size) throw new AppError(422, 'UNKNOWN_PRODUCT_ID');
      return rows;
    },
    async apply(key, hash, scene, metadata, catalog, signal) {
      signal.throwIfAborted();
      // A single RPC = one PostgreSQL transaction, including idempotency and alerts.
      return unwrap(await db.rpc('aplicar_evento', {
        p_id: key, p_hash: hash, p_scene: scene, p_meta: metadata,
        p_versions: Object.fromEntries(catalog.map(p => [p.id, p.actualizado_en]))
      }).abortSignal(signal), signal);
    }
  };
}
